package src.entities;

public class Chessboard {
	// White bitboards
	public long WP=0L;
	public long WN=0L;
	public long WB=0L;
	public long WR=0L;
	public long WQ=0L; 
	public long WK=0L;
	
	// Black bitboards
	public long BP=0L;
	public long BN=0L;
	public long BB=0L;
	public long BR=0L;
	public long BQ=0L;
	public long BK=0L;

}
