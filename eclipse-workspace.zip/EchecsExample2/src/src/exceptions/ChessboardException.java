package src.exceptions;

public class ChessboardException extends Exception {
}
