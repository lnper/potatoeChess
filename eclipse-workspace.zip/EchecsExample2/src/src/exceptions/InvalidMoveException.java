package src.exceptions;

public class InvalidMoveException extends Exception {
}
