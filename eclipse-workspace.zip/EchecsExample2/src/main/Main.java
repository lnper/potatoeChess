package main;

import src.io.UCI;

public class Main {

	public static void main(String[] args) {
		UCI.uciCommunication();
	}

}
